<?php
/**
 * Emoji reactions on block comments (notes) for WordPress 7.2.
 *
 * Extends note-related block comment functions to support the 'reaction'
 * comment type used for emoji reactions on notes.
 *
 * Why a custom comment type (vs. comment meta on the parent note)?
 *
 * - Each reaction has a real author, date, and ID, so existing comment
 *   APIs handle authorship, timestamps, and deletion without bespoke code.
 *   This avoids client-side date math and timezone bugs.
 * - The type is generic ('reaction', not 'note_reaction') so it can later
 *   attach to any commentable resource (blocks, posts, other comment types),
 *   not just block notes.
 * - Race conditions when adding/removing reactions concurrently are handled
 *   by the comments table (one row per reaction) rather than by read-modify-
 *   write on a serialized meta value.
 *
 * Background discussion: https://github.com/WordPress/gutenberg/pull/75549
 * and https://github.com/WordPress/gutenberg/pull/75148.
 *
 * @package gutenberg
 * @since   7.2.0
 */

/**
 * Updates the comment type for avatars to include internal comment types.
 *
 * Adds the 'reaction' type to core's default 'comment' and 'note' avatar
 * comment types.
 *
 * @param string[] $comment_type The array of comment types.
 * @return string[] The updated array of comment types.
 *
 * @phpstan-return non-empty-list<string>
 */
function gutenberg_update_get_avatar_comment_type_7_2( $comment_type ) {
	return array_values( array_unique( array_merge( $comment_type, array( 'note', 'reaction' ) ) ) );
}
add_filter( 'get_avatar_comment_types', 'gutenberg_update_get_avatar_comment_type_7_2' );

/**
 * Excludes reactions from comment queries unless they are requested.
 *
 * Core's WP_Comment_Query already excludes 'note' unless 'all' or 'note' is
 * requested; this applies the same rule to 'reaction'.
 *
 * @global wpdb $wpdb WordPress database abstraction object.
 *
 * @param string[]         $clauses The current SQL clauses for the comments query.
 * @param WP_Comment_Query $query   The current comments query.
 *
 * @return string[] The modified SQL clauses for the comments query.
 */
function gutenberg_exclude_block_comments_from_admin_7_2( $clauses, WP_Comment_Query $query ) {
	$types_in     = array_merge( (array) $query->query_vars['type'], (array) $query->query_vars['type__in'] );
	$types_not_in = (array) $query->query_vars['type__not_in'];

	if (
		in_array( 'all', $types_in, true ) ||
		in_array( 'reaction', $types_in, true ) ||
		in_array( 'reaction', $types_not_in, true )
	) {
		return $clauses;
	}

	global $wpdb;
	$clauses['where'] .= " AND {$wpdb->comments}.comment_type != 'reaction'";

	return $clauses;
}
add_filter( 'comments_clauses', 'gutenberg_exclude_block_comments_from_admin_7_2', 10, 2 );

/**
 * Excludes internal comment types from comment feeds.
 *
 * WP_Query builds the comment feed SQL directly (not via WP_Comment_Query)
 * and only hardcodes the 'note' exclusion, so reactions would otherwise
 * appear in public comment feeds.
 *
 * @global wpdb $wpdb WordPress database abstraction object.
 *
 * @param string $cwhere The WHERE clause of the comment feed query.
 * @return string The modified WHERE clause.
 */
function gutenberg_exclude_internal_comment_types_from_feed_7_2( $cwhere ) {
	global $wpdb;
	return $cwhere . " AND {$wpdb->comments}.comment_type NOT IN ( 'note', 'reaction' )";
}
add_filter( 'comment_feed_where', 'gutenberg_exclude_internal_comment_types_from_feed_7_2' );

/**
 * Filter the comment count query to exclude notes and reactions.
 *
 * Core hardcodes the 'note' exclusion in this query; this also excludes
 * 'reaction'.
 *
 * @param string $query The SQL query string.
 * @return string The modified SQL query string.
 */
function gutenberg_filter_comment_count_query_exclude_block_comments_7_2( $query ) {
	if ( str_starts_with( $query, 'SELECT comment_post_ID, COUNT(comment_ID) as num_comments FROM' ) && str_contains( $query, 'comment_approved' ) ) {
		/*
		 * Add an exclusion clause for each internal type not already present.
		 * Core's query already hardcodes the note-only exclusion, so expanding
		 * per type - rather than bailing when any exclusion exists - ensures
		 * reactions are excluded too and keeps the filter idempotent if it
		 * runs more than once.
		 */
		$type_clauses = array();
		foreach ( array( 'note', 'reaction' ) as $internal_type ) {
			$clause = "comment_type != '" . esc_sql( $internal_type ) . "'";
			if ( ! str_contains( $query, $clause ) ) {
				$type_clauses[] = $clause;
			}
		}
		if ( ! empty( $type_clauses ) ) {
			$query = str_replace( 'comment_approved', implode( ' AND ', $type_clauses ) . ' AND comment_approved', $query );
		}
	}
	return $query;
}
add_filter( 'query', 'gutenberg_filter_comment_count_query_exclude_block_comments_7_2' );

/**
 * Excludes notes and reactions from the last comment modified lookup.
 *
 * Both are stored approved, so get_lastcommentmodified() would otherwise
 * report a note or reaction as the site's latest comment, for example in
 * the comment feed's Last-Modified header.
 *
 * @global wpdb $wpdb WordPress database abstraction object.
 *
 * @param string $query The SQL query string.
 * @return string The modified SQL query string.
 */
function gutenberg_exclude_internal_comment_types_from_lastcommentmodified_7_2( $query ) {
	global $wpdb;

	$needle = "FROM $wpdb->comments WHERE comment_approved = '1' ORDER BY comment_date_gmt DESC LIMIT 1";
	if ( ! str_starts_with( $query, 'SELECT ' ) || ! str_ends_with( $query, $needle ) ) {
		return $query;
	}

	return str_replace( "comment_approved = '1' ORDER BY", "comment_approved = '1' AND comment_type NOT IN ( 'note', 'reaction' ) ORDER BY", $query );
}
add_filter( 'query', 'gutenberg_exclude_internal_comment_types_from_lastcommentmodified_7_2' );

/**
 * Adjusts the comments list table query so notes and reactions never display.
 *
 * Extends core's 'note' guard in WP_Comments_List_Table to the 'reaction'
 * type.
 *
 * @param array $args An array of get_comments() arguments.
 * @return array Possibly modified arguments for get_comments().
 */
function gutenberg_hide_note_from_comment_list_table_7_2( $args ) {
	if ( ! empty( $_REQUEST['comment_type'] ) && in_array( $_REQUEST['comment_type'], array( 'note', 'reaction' ), true ) ) {
		unset( $args['type'] );
	}
	return $args;
}
add_filter( 'comments_list_table_query_args', 'gutenberg_hide_note_from_comment_list_table_7_2' );

/**
 * Override comment_count to exclude notes and reactions from the comment count.
 *
 * Core's default count excludes only 'note'; this also excludes 'reaction'.
 *
 * @param int|null $new_count The new comment count. Default null.
 * @param int      $old_count The old comment count.
 * @param int      $post_id   Post ID.
 * @return int|null The modified comment count.
 */
function gutenberg_exclude_notes_from_comment_count_7_2( $new_count, $old_count, $post_id ) {
	global $wpdb;
	if ( null !== $new_count ) {
		return $new_count;
	}
	$new_count = (int) $wpdb->get_var(
		$wpdb->prepare(
			"SELECT COUNT(*) FROM $wpdb->comments WHERE comment_post_ID = %d AND comment_approved = '1' AND comment_type NOT IN ( 'note', 'reaction' )",
			$post_id
		)
	);
	return $new_count;
}
add_filter( 'pre_wp_update_comment_count_now', 'gutenberg_exclude_notes_from_comment_count_7_2', 10, 3 );

/**
 * Returns the reaction children of a note.
 *
 * @since 7.2.0
 *
 * @param WP_Comment $note   The note whose reactions to fetch.
 * @param string     $status Comment status to match. Default 'any', which
 *                           includes trashed reactions.
 * @return int[] Reaction comment IDs, oldest first.
 */
function gutenberg_get_note_reaction_ids( WP_Comment $note, string $status = 'any' ): array {
	return get_comments(
		array(
			'parent'  => $note->comment_ID,
			'type'    => 'reaction',
			'status'  => $status,
			'fields'  => 'ids',
			'orderby' => 'comment_ID',
			'order'   => 'ASC',
		)
	);
}

/**
 * Permanently deletes a note's reactions along with the note.
 *
 * `wp_delete_comment()` reparents a deleted comment's children one level up
 * rather than deleting them, so reactions would otherwise survive their note
 * as approved, orphaned rows still carrying the reactor's identity. Core
 * cascades only `note` children (see `wp_trash_comment()`), so reactions need
 * their own cascade.
 *
 * Runs on `delete_comment`, which fires before the reparenting query.
 *
 * @since 7.2.0
 *
 * @param string     $comment_id The comment ID as a numeric string.
 * @param WP_Comment $comment    The comment being deleted.
 *
 * @phpstan-param numeric-string $comment_id
 */
function gutenberg_delete_note_reactions( $comment_id, WP_Comment $comment ): void {
	if ( 'note' !== $comment->comment_type ) {
		return;
	}

	/*
	 * Every status: trashing the note, or a REST delete without `force`,
	 * leaves reactions in the trash.
	 */
	foreach ( gutenberg_get_note_reaction_ids( $comment ) as $reaction_id ) {
		wp_delete_comment( $reaction_id, true );
	}
}
add_action( 'delete_comment', 'gutenberg_delete_note_reactions', 10, 2 );

/**
 * Trashes a note's reactions along with the note.
 *
 * Core cascades a trashed note to its `note` children only, so reactions
 * would otherwise stay approved under a trashed note. Replies are covered
 * because core trashes each one, which fires this action again.
 *
 * Restoring the note does not bring its reactions back: core's
 * `wp_untrash_comment()` restores no children of any type, so restoring
 * children is left to a cascade that covers every child type together.
 *
 * @since 7.2.0
 *
 * @param string     $comment_id The comment ID as a numeric string.
 * @param WP_Comment $comment    The trashed comment.
 *
 * @phpstan-param numeric-string $comment_id
 */
function gutenberg_trash_note_reactions( $comment_id, WP_Comment $comment ): void {
	if ( 'note' !== $comment->comment_type ) {
		return;
	}

	foreach ( gutenberg_get_note_reaction_ids( $comment, 'approve' ) as $reaction_id ) {
		wp_trash_comment( $reaction_id );
	}
}
add_action( 'trashed_comment', 'gutenberg_trash_note_reactions', 10, 2 );
