<?php
/**
 * Bootstraps the Gutenberg experiments page in wp-admin.
 *
 * @package gutenberg
 */

/**
 * Set up the experiments settings.
 *
 * Registering an experiment here only exposes it on the Experiments screen.
 * To actually enable a new experiment in the editor, add a matching bridge
 * (e.g. a `window.__experimental*` global) in `gutenberg_enable_experiments()`
 * in `lib/experimental/editor-settings.php`.
 */
function gutenberg_initialize_experiments_settings() {
	$groups = array(
		array(
			'slug'  => 'blocks',
			'label' => _x( 'Blocks', 'experiments group name', 'gutenberg' ),
			'items' => array(
				array(
					'id'          => 'gutenberg-block-experiments',
					'label'       => __( 'Experimental blocks', 'gutenberg' ),
					'description' => __( 'Enables experimental blocks on a rolling basis as they are developed. (Warning: these blocks may have significant changes during development that cause validation errors and display issues.)', 'gutenberg' ),
				),
				array(
					'id'          => 'gutenberg-global-styles-inheritance-ui',
					'label'       => __( 'Global Styles inheritance indicators in the block inspector', 'gutenberg' ),
					'description' => __( 'Marks which block inspector controls show a value inherited from Global Styles, and adds a shortcut to clear a value you set back to the inherited one. Inherited values show in the inspector whether or not this is on.', 'gutenberg' ),
				),
				array(
					'id'          => 'gutenberg-block-toolbar-redesign',
					'label'       => __( 'Block toolbar redesign', 'gutenberg' ),
					'description' => __( 'Tries a redesigned block toolbar: a block name button for transforms and style presets, bigger movers, a searchable options menu with labelled items, a parent selector that keeps the toolbar in place, and a separate toolbar for formatting selected text.', 'gutenberg' ),
				),
				array(
					'id'          => 'gutenberg-grid-interactivity',
					'label'       => __( 'Grid interactivity', 'gutenberg' ),
					'description' => __( 'Enables enhancements to the Grid block that let you move and resize items in the editor canvas.', 'gutenberg' ),
				),
			),
		),
		array(
			'slug'  => 'media',
			'label' => _x( 'Media', 'experiments group name', 'gutenberg' ),
			'items' => array(
				array(
					'id'          => 'gutenberg-media-editor',
					'label'       => __( 'Media Editor (Route)', 'gutenberg' ),
					'description' => __( 'Replaces the core Edit Media screen with a dedicated route-based media editor for editing media items (metadata and content).', 'gutenberg' ),
				),
				array(
					'id'          => 'gutenberg-dataviews-media-modal',
					'label'       => __( 'Media Upload Modal', 'gutenberg' ),
					'description' => __( 'Replaces the existing WordPress media modal with a new modal powered by Data Views, supporting browsing, selecting, and uploading media.', 'gutenberg' ),
				),
			),
		),
		array(
			'slug'  => 'interactivity',
			'label' => _x( 'Interactivity', 'experiments group name', 'gutenberg' ),
			'items' => array(
				array(
					'id'          => 'gutenberg-full-page-client-side-navigation',
					'label'       => __( 'Full-page client-side navigation', 'gutenberg' ),
					'description' => __( 'Enables full-page client-side navigation, powered by the Interactivity API.', 'gutenberg' ),
				),
			),
		),
		array(
			'slug'  => 'real-time-collaboration',
			'label' => _x( 'Real-Time Collaboration', 'experiments group name', 'gutenberg' ),
			'items' => array(
				array(
					'id'          => 'gutenberg-real-time-collaboration',
					'label'       => __( 'Enable real-time collaboration', 'gutenberg' ),
					'description' => __( 'Allows multiple people to edit the same post at the same time.', 'gutenberg' ),
				),
			),
		),
		array(
			'slug'  => 'other',
			'label' => _x( 'Other', 'experiments group name', 'gutenberg' ),
			'items' => array(
				array(
					'id'          => 'gutenberg-workflow-palette',
					'label'       => __( 'Workflow Palette', 'gutenberg' ),
					'description' => __( 'Enables the Workflow Palette for running workflows composed of abilities, from a unified interface.', 'gutenberg' ),
				),
				array(
					'id'          => 'gutenberg-extensible-site-editor',
					'label'       => __( 'Extensible Site Editor', 'gutenberg' ),
					'description' => __( 'Redirects the default site editor (Appearance > Design) to use the extensible site editor page.', 'gutenberg' ),
				),
				array(
					'id'          => 'gutenberg-guidelines',
					'label'       => __( 'Guidelines', 'gutenberg' ),
					'description' => __( 'Enables the Guidelines page under Settings and the experimental knowledge storage (wp_knowledge).', 'gutenberg' ),
				),
				array(
					'id'          => 'gutenberg-wpds-admin-restyle',
					'label'       => __( 'Admin design tokens', 'gutenberg' ),
					'description' => __( 'Styles wp-admin from WordPress Design System tokens, so every admin screen reads as one product regardless of how it is rendered. No markup changes. (Warning: this can change how plugin styles apply to admin screens, and it loads admin stylesheets one by one instead of combined. Use it for testing, not on a live site.)', 'gutenberg' ),
				),
				array(
					'id'          => 'gutenberg-dashboard-widgets',
					'label'       => __( 'New Dashboard experience', 'gutenberg' ),
					'description' => __( 'Enables a new dashboard experience with resizable, reorderable widgets that plugins can register and users can personalize.', 'gutenberg' ),
				),
				array(
					'id'          => 'gutenberg-react-19',
					'label'       => __( 'React 19', 'gutenberg' ),
					'description' => __( 'Uses React 19 for the registered React scripts, instead of the legacy React 18 version. Can be disabled when the new React 19 script cause compatibility issues with plugins and themes.', 'gutenberg' ),
				),
			),
		),
	);

	$properties = array();

	foreach ( $groups as $group ) {
		foreach ( $group['items'] as $experiment ) {
			$property = array(
				'type'        => 'boolean',
				'title'       => $experiment['label'],
				'description' => $experiment['description'],
				'group'       => $group['slug'],
				'group_label' => $group['label'],
				'default'     => gutenberg_get_experiment_default( $experiment['id'] ),
			);

			$properties[ $experiment['id'] ] = $property;
		}
	}

	register_setting(
		'gutenberg-experiments',
		'gutenberg-experiments',
		array(
			'label'        => __( 'Gutenberg Experiments', 'gutenberg' ),
			'show_in_rest' => array(
				'schema' => array(
					'type'                 => 'object',
					'properties'           => $properties,
					/*
					 * A site that enabled an experiment which was since removed still
					 * carries that ID in the saved option.
					 */
					'additionalProperties' => array(
						'type' => 'boolean',
					),
				),
			),
			'default'      => array(),
		)
	);
}

add_action( 'rest_api_init', 'gutenberg_initialize_experiments_settings' );

/**
 * Allows the legacy `gutenberg-experiments` route. Without this, accessing
 * `?page=gutenberg-experiments` results in an HTTP 403 error.
 *
 * Allowing the route is done by adding a wp-admin submenu page that won't be rendered.
 */
function gutenberg_experiments_legacy_menu() {
	add_submenu_page( '', '', '', 'manage_options', 'gutenberg-experiments', '__return_empty_string' );
}
add_action( 'admin_menu', 'gutenberg_experiments_legacy_menu', 9 );

/**
 * Redirects the legacy `?page=gutenberg-experiments` URL to the new
 * `?page=experiments-wp-admin` URL.
 */
function gutenberg_redirect_legacy_experiments_page() {
	wp_safe_redirect( admin_url( 'options-general.php?page=experiments-wp-admin' ) );
	exit;
}
add_action( 'load-admin_page_gutenberg-experiments', 'gutenberg_redirect_legacy_experiments_page' );
