<?php
/**
 * Admin design tokens: loader and cascade layer setup.
 *
 * Styles wp-admin from WordPress Design System tokens, so every admin screen
 * reads as one product regardless of how it is rendered. Gated by the
 * `gutenberg-wpds-admin-restyle` experiment; when it is off this file is never
 * loaded and nothing changes.
 *
 * MECHANISM — cascade layers, no dependency surgery.
 *
 * Layered CSS *loses* to unlayered CSS, so simply shipping our styles inside
 * `@layer wpds` would be outranked by WordPress's unlayered admin CSS. Rather than
 * dequeue WordPress's stylesheets and rewire the dependency graph (which is what the
 * earlier POC did, and where its cost and its escaped bugs lived), we rewrite
 * the `<link>` tag for an explicit allowlist of WordPress style handles into an
 * `@import ... layer(wp-legacy)`. The handle stays registered and enqueued, the
 * dependency graph is untouched, and WordPress's rules land in a layer below ours.
 *
 * Consequences, all verified by rendering rather than by reading CSS:
 *  - our styles beat WordPress's, regardless of selector specificity;
 *  - unlayered third-party plugin CSS still beats ours, which preserves the
 *    override the ecosystem has always relied on;
 *  - EXCEPT for `!important`, where layer priority reverses and a layered
 *    `!important` would beat a plugin's unlayered one. Hence the hard no-
 *    `!important` rule in the stylesheets, enforced by stylelint.
 *
 * This is prototype-grade. `@import` is render-blocking and costs a round trip
 * per demoted sheet. The permanent form is for these styles to move into
 * WordPress's own admin stylesheets, one change at a time. Layers are
 * scaffolding for reaching those stylesheets from a plugin: once the styles
 * live there, this whole demotion step is deleted. Wrapping WordPress's admin
 * CSS in `@layer` instead would not do it, because every unlayered plugin rule
 * would then outrank the admin unconditionally.
 *
 * @package gutenberg
 */

/**
 * Disables admin style concatenation while the experiment is on.
 *
 * By default wp-admin bundles its stylesheets into a single `load-styles.php`
 * request, and `WP_Styles::do_item()` short-circuits before the
 * `style_loader_tag` filter when it is concatenating. `buttons` therefore never
 * gets its own `<link>` and cannot be demoted into a layer.
 *
 * Setting this global is the documented plugin-facing way to opt out (see the
 * file header of WordPress's script-loader.php). The cost is more requests on admin
 * screens, which is acceptable for an off-by-default experiment.
 *
 * NOTE: this is scaffolding, and it is a second reason the permanent fix
 * belongs in WordPress itself. Once these styles live in WordPress's own admin
 * stylesheets, both this and the demotion filter below are deleted and
 * concatenation stays on.
 *
 * An alternative was considered and rejected: demoting the entire
 * `load-styles.php` bundle in one go. That would put *all* of WordPress's admin CSS
 * below unlayered plugin CSS, so plugin rules that currently lose on
 * specificity or source order would suddenly win. That is a large and silent
 * behaviour change for the ecosystem, and the opposite of the small, explicit
 * blast radius this experiment is built around.
 *
 * @since 24.1.0
 *
 * @global bool $concatenate_scripts
 */
function gutenberg_wpds_admin_disable_concatenation() {
	// phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
	$GLOBALS['concatenate_scripts'] = false;
}
add_action( 'admin_init', 'gutenberg_wpds_admin_disable_concatenation' );

/**
 * Declares the layer order.
 *
 * Layer order is fixed by FIRST APPEARANCE in the document, not by the load
 * order of the stylesheets themselves. Rather than reason about hook priority,
 * every style element this experiment emits — the demoted imports and our own
 * stylesheets alike — repeats this same declaration. They all agree, so
 * whichever lands first sets the order correctly.
 *
 * @since 24.1.0
 */
const GUTENBERG_WPDS_ADMIN_LAYER_ORDER = '@layer wpds-overrides, wp-legacy, wpds;';

/**
 * WordPress style handles to demote into the `wp-legacy` layer.
 *
 * Deliberately an explicit allowlist rather than a blanket rewrite: the blast
 * radius is exactly what is named here, and it grows one control at a time.
 *
 * The set must be CONSISTENT, not minimal. WordPress's stylesheets override each
 * other by source order — most visibly, the active admin colour scheme
 * (`colors`) restyles the chrome defined in `admin-menu`, `common`, `forms` and
 * the rest. Demoting only some of them inverts those relationships: demoting
 * `colors` alone put the modern scheme's `#adminmenuback { background: #1e1e1e }`
 * below the unlayered `admin-menu.css` default of `#1d2327`, silently reverting
 * the admin colour scheme to legacy colours. So the whole admin set moves
 * together, preserving their existing order relative to one another.
 *
 * DELIBERATELY EXCLUDED: Gutenberg's own package styles, above all
 * `wp-base-styles`. Gutenberg points that handle at its own build, and it is
 * what defines `--wp-admin-theme-color` per scheme via `body.admin-color-*`
 * (specificity 0,2,0). Other Gutenberg package styles define the same custom
 * property unlayered on `:root` (0,1,0). Demote `wp-base-styles` and those
 * unlayered `:root` definitions win, taking the accent colour with them. It
 * stays unlayered, and it does not need demoting — those styles are already
 * design-system aligned.
 *
 * ALSO EXCLUDED: `media`. Demotion turns a `<link>` into an `@import`, which the
 * browser fetches only after it has parsed the importing element, so the
 * stylesheet lands later than a link would. The media grid measures its frame in
 * JavaScript as the page initialises, and with `media-views.css` still in flight
 * it measures an unstyled frame, computes a collapsed height and never
 * recalculates: upload.php?mode=grid renders as an empty strip. Verified by
 * removing this one handle. Any screen that sizes itself from measured CSS is
 * exposed the same way, which is one more thing that only moving these styles
 * into WordPress's own stylesheets can fix. The cost of leaving it out is that
 * `media-views.css` outranks the demoted colour scheme's media rules; a wrongly-coloured modal is a better
 * failure than an unusable Media Library.
 *
 * Trade-off worth naming: everything listed here now sits below unlayered
 * plugin CSS. Plugin rules that currently lose to WordPress's stylesheets on
 * specificity or source order will start winning. That is a real behaviour change for the ecosystem
 * and the main thing this experiment needs to prove is safe.
 *
 * @since 24.1.0
 *
 * @return string[] Array of registered style handles.
 */
function gutenberg_wpds_admin_demoted_handles() {
	return array(
		// Controls and chrome.
		'buttons',
		'common',
		'forms',
		'admin-menu',
		'admin-bar',
		'list-tables',
		'edit',
		'dashboard',
		'revisions',
		'themes',
		'about',
		'nav-menus',
		'widgets',
		'site-icon',
		'l10n',
		'wp-tooltip',
		'dashicons',
		// The active admin colour scheme. Must move with everything above.
		'colors',
	);
}

/**
 * Escapes a URL for use inside a CSS string in an inline `<style>` element.
 *
 * The URL arrives HTML-escaped: `WP_Styles::_css_href()` returns `esc_url()`,
 * which encodes `&` as `&#038;` and `'` as `&#039;`. CSS does not decode HTML
 * entities, so a URL carrying more than one query argument would be requested
 * with the entity still in it. Decode those first, then sanitise, then guard
 * the CSS string context and the containing element.
 *
 * `wp_specialchars_decode()` with `ENT_QUOTES` is the matching decoder: it
 * handles exactly the `&#038;` and `&#039;` that `esc_url()` produces.
 *
 * @since 24.1.0
 *
 * @param string $href URL to escape.
 * @return string Escaped URL, safe inside a double-quoted CSS string.
 */
function gutenberg_wpds_admin_escape_css_url( $href ) {
	return str_replace(
		array( '\\', '"', '<' ),
		array( '\\\\', '\\"', '\\3c ' ),
		esc_url_raw( wp_specialchars_decode( $href, ENT_QUOTES ) )
	);
}

/**
 * Rewrites an allowlisted WordPress stylesheet link into a layered `@import`.
 *
 * Fires for the RTL variant as a second call with the same handle, so both
 * directions are demoted without any extra handling.
 *
 * @since 24.1.0
 *
 * @param string $tag    The `<link>` tag for the enqueued style.
 * @param string $handle The style's registered handle.
 * @param string $href   The stylesheet URL.
 * @param string $media  The stylesheet's media attribute.
 * @return string The original tag, or an inline style element importing it into a layer.
 */
function gutenberg_wpds_admin_demote_style( $tag, $handle, $href, $media ) {
	if ( ! is_admin() ) {
		return $tag;
	}

	if ( ! in_array( $handle, gutenberg_wpds_admin_demoted_handles(), true ) ) {
		return $tag;
	}

	/*
	 * The colour scheme picker previews a scheme by setting `href` on
	 * `#colors-css` (wp-admin/js/user-profile.js). Demoting that handle replaces
	 * the `<link>` with a `<style>` carrying an `@import`, and setting `href` on
	 * a `<style>` does nothing — the preview silently stops working until the
	 * page is reloaded.
	 *
	 * So the `colors` handle keeps its `<link>` on the two screens that render
	 * the picker. The cost is that the scheme's stylesheet is unlayered there
	 * and so outranks this experiment's rules on those screens only; the
	 * alternative is breaking a WordPress feature, which is worse. A permanent
	 * version of this restyle lives in WordPress's own stylesheets and has no
	 * demotion step, so nothing here needs solving upstream.
	 */
	if ( 'colors' === $handle && in_array( $GLOBALS['pagenow'] ?? '', array( 'profile.php', 'user-edit.php' ), true ) ) {
		return $tag;
	}

	if ( empty( $href ) ) {
		return $tag;
	}

	// Media list goes after layer() in the @import prelude. 'all' is the default.
	$media_suffix = ( $media && 'all' !== $media ) ? ' ' . $media : '';

	return sprintf(
		"<style id=\"%s-css\" data-wpds-demoted=\"1\">%s\n@import url(\"%s\") layer(wp-legacy)%s;</style>\n",
		esc_attr( $handle ),
		GUTENBERG_WPDS_ADMIN_LAYER_ORDER,
		gutenberg_wpds_admin_escape_css_url( $href ),
		$media_suffix
	);
}
add_filter( 'style_loader_tag', 'gutenberg_wpds_admin_demote_style', 10, 4 );

/**
 * Returns the version string used for the restyle's stylesheets.
 *
 * @since 24.1.0
 *
 * @return string Version string.
 */
function gutenberg_wpds_admin_style_version() {
	return defined( 'GUTENBERG_VERSION' ) && ! SCRIPT_DEBUG ? GUTENBERG_VERSION : (string) time();
}

/**
 * Enqueues the design tokens and returns the handle to depend on.
 *
 * Gutenberg registers `wp-theme` in lib/client-assets.php. The prebuilt copy is
 * a fallback in case that registration goes away.
 *
 * @since 24.1.0
 *
 * @return string[] Handles the first stylesheet should depend on.
 */
function gutenberg_wpds_admin_token_dependencies() {
	if ( wp_style_is( 'wp-theme', 'registered' ) ) {
		wp_enqueue_style( 'wp-theme' );

		return array( 'wp-theme' );
	}

	wp_enqueue_style(
		'gutenberg-wpds-admin-tokens',
		gutenberg_url( 'packages/theme/prebuilt/css/design-tokens.css' ),
		array(),
		gutenberg_wpds_admin_style_version()
	);

	return array( 'gutenberg-wpds-admin-tokens' );
}

/**
 * Enqueues every stylesheet in a directory, in filename order.
 *
 * The numeric filename prefixes set the order, and each sheet depends on the
 * previous one so the HTML comes out in that order too. A new area of the
 * restyle is a new file in the directory; nothing needs registering here.
 *
 * @since 24.1.0
 *
 * @param string   $directory  Absolute path to the directory to read.
 * @param string   $url_path   Path of that directory relative to the plugin root.
 * @param string   $prefix     Handle prefix for the stylesheets found there.
 * @param string[] $first_deps Handles the first stylesheet depends on.
 */
function gutenberg_wpds_admin_enqueue_directory( $directory, $url_path, $prefix, $first_deps ) {
	$files = glob( $directory . '/*.css' );

	if ( empty( $files ) ) {
		return;
	}

	sort( $files );

	$version  = gutenberg_wpds_admin_style_version();
	$base_url = gutenberg_url( $url_path );
	$previous = null;

	foreach ( $files as $file ) {
		$handle = $prefix . basename( $file, '.css' );

		wp_enqueue_style(
			$handle,
			$base_url . basename( $file ),
			null === $previous ? $first_deps : array( $previous ),
			$version
		);

		$previous = $handle;
	}
}

/**
 * Enqueues design tokens and the restyle stylesheets on admin screens.
 *
 * `admin_enqueue_scripts` only fires in wp-admin, so the login screen and the
 * front end (which also use `buttons`) are not affected.
 *
 * @since 24.1.0
 */
function gutenberg_wpds_admin_enqueue_styles() {
	/*
	 * Depending on `buttons` prints our sheets after the demoted core one. Layer
	 * order decides the cascade regardless; this keeps the HTML readable.
	 */
	gutenberg_wpds_admin_enqueue_directory(
		__DIR__ . '/css',
		'lib/experimental/wpds-admin/css/',
		'gutenberg-wpds-admin-',
		array_merge( gutenberg_wpds_admin_token_dependencies(), array( 'buttons' ) )
	);
}
add_action( 'admin_enqueue_scripts', 'gutenberg_wpds_admin_enqueue_styles' );

/**
 * Enqueues the front-end stylesheets on pages that render the admin bar.
 *
 * The front-end sheets live in `css/front/` because they cannot be wrapped in
 * `@layer`. Core's admin-bar.css is unlayered on the front end, and unlayered
 * CSS always wins over layered CSS. Keeping them separate also limits what
 * loads next to the theme to the admin bar rules alone.
 *
 * @since 24.1.0
 */
function gutenberg_wpds_admin_enqueue_front_styles() {
	if ( ! is_admin_bar_showing() ) {
		return;
	}

	/*
	 * Between two unlayered sheets of equal specificity the later one wins, so
	 * ours has to come after `admin-bar`.
	 */
	gutenberg_wpds_admin_enqueue_directory(
		__DIR__ . '/css/front',
		'lib/experimental/wpds-admin/css/front/',
		'gutenberg-wpds-admin-front-',
		array_merge( gutenberg_wpds_admin_token_dependencies(), array( 'admin-bar' ) )
	);
}
add_action( 'wp_enqueue_scripts', 'gutenberg_wpds_admin_enqueue_front_styles' );

require_once __DIR__ . '/harness.php';
